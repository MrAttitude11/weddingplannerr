<section class="header">

   <a href="home.php" class="logo">PARMAR EVENT EGENCY.</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="about.php">about</a>
      <a href="portfolio.php">portfolio</a>
      <a href="pricing.php">pricing</a>
      <a href="contact.php">contact</a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>